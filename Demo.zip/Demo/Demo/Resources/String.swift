//
//  String.swift
//  JMP
//
//  Created by Nishant Gupta on 16/04/19.
//  Copyright © 2019 GTrac. All rights reserved.
//

import Foundation
extension String {
    func stringToInt() -> Int? {
        if let b = Int(self) {
            return b
        }
        else {
            return 0
        }
    }
    func convertDateFormater(_ date: String) -> String
    {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd"
        let date = dateFormatter.date(from: date)
        dateFormatter.dateFormat = "MMM dd, yyyy"
        return  dateFormatter.string(from: date!)
        
    }
    
    func convertDateFormaterTrip(_ date: String) -> String
    {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd-MM-yyyy"
        let date = dateFormatter.date(from: date)
        dateFormatter.dateFormat = "dd MMM, yyyy"
        return  dateFormatter.string(from: date!)
        
    }
    func convertDateFormaterRequestDoc(_ date: String) -> String
    {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
        let date = dateFormatter.date(from: date)
        dateFormatter.dateFormat = "dd/MM/yyyy"
        return  dateFormatter.string(from: date!)
        
    }
    func toDouble() -> Double {
        if let unwrappedNum = Double(self) {
            return unwrappedNum
        } else {
            // Handle a bad number
            return 0.0
        }
    }
    func toFloat() -> Float {
        if let unwrappedNum = Float(self) {
            return unwrappedNum
        } else {
            // Handle a bad number
            return 0.0
        }
    }
    func localized(comment: String = "") -> String {
        return NSLocalizedString(self, comment: comment)
    }
}
