//
//  WebServices.swift
//  JMP
//
//  Created by Nishant Gupta on 16/04/19.
//  Copyright © 2019 GTrac. All rights reserved.
//

import Foundation
import Alamofire
import AlamofireImage
import SVProgressHUD

class WebServices: NSObject {
    
    
    static var shared = WebServices()
 
    // let urlBase = "https://www.mybtion/api/api.php"
    private override init() {
        
    }
    //MARK: - getLogin
    func getLogin(EmailID: String ,Password: String,Platform: String, completion: @escaping (_ success:[String: Any]? ,_ error:Error?) -> Void) {
        SVProgressHUD.show(withStatus: "Loading...")
        SVProgressHUD.setDefaultMaskType(.clear)
        let parameters:[String: String] = ["email": EmailID,"password":Password,"device":Platform]
       

        let url = URL(string: AppConstants.kBASE_SERVICE_URL )
        print("URL: \(String(describing: url!)) ")
        print("Parameter:  \(parameters)")

        Alamofire.request(url!, method: .post, parameters: parameters, encoding: URLEncoding.default, headers: nil).responseJSON(completionHandler: {response in
            switch(response.result){
            case .success(_):
                if let data = response.result.value as? [String: Any]{
                    completion(data, nil)
                    print("Response:  \(data)")
                    SVProgressHUD.dismiss()
                }
                else{
                    completion(nil, nil)
                    SVProgressHUD.dismiss()
                }
                break
            case .failure(_):
                let err = response.result.error
                completion(nil, err)
                print("Response:  \(String(describing: err))")

                SVProgressHUD.dismiss()
                break
            }
        })
    }

    
    //MARK: - getAllDocApi
    
    func getAllDocApi(requestId: String, completion: @escaping (_ success:[String: Any]? ,_ error:Error?) -> Void) {
        SVProgressHUD.show(withStatus: "Loading...")
        SVProgressHUD.setDefaultMaskType(.clear)
        //{{jmp_base_url}}jmpchampion/getFlightbyId?flight_id=1
        
        let url = URL(string: AppConstants.kBASE_SERVICE_URL)
        print("URL: \(String(describing: url!)) ")
        
        let headers: HTTPHeaders = [
            "auth_token": "",
            "Accept": "application/json"
        ]
        print(headers)
        
        Alamofire.request(url!, method: .get, encoding: URLEncoding.default, headers: headers).responseJSON(completionHandler: { response in
            switch(response.result){
            case .success(_):
                if let data = response.result.value as? [String: Any]{
                    completion(data, nil)
                    SVProgressHUD.dismiss()
                    print("Response:  \(data)")
                }
                else{
                    completion(nil, nil)
                    SVProgressHUD.dismiss()
                }
                break
            case .failure(_):
                let err = response.result.error
                completion(nil, err)
                print("Response:  \(String(describing: err))")
                
                SVProgressHUD.dismiss()
                break
            }
        })
    }

    

    
}
//func RegistrationApiCall(){
//    WebServices.shared.signUp(FullName: nameTxtField.text!, Email: emailTxtField.text!, Password: passwordTxtField.text!, Phone: contactTxtField.text!, CountryName: self.countryNameStr, ProfilePic:AppConstants.kBASE_SERVICE_JMP_IMAGEURL + profilePicStr, PassportNumber: passportTxtField.text!, PassportPic:AppConstants.kBASE_SERVICE_JMP_IMAGEURL + passportStr,  completion:  {(response,error) in
//        if error == nil{
//            //  self.profileModels.removeAll()
//            let code = response![AppConstants.CODETXT] as! Int
//            let message = response![AppConstants.MESSAGETXT] as! String
//            //let type = response![AppConstants.TYPETXT] as! String
//            
//            switch(code){
//            case AppConstants.ONEINT:
//                
//                
//                self.showWithBackToast(message: message)
//                
//                
//                
//                break
//            case AppConstants.ZEROINT:
//                
//                self.showToast(message: message)
//                
//            default:
//                break
//            }
//        }else{
//            self.showWithBackToast(message: "Something went wrong")
//            
//        }
//    })
//}
