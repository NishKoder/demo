//
//  UIDatePicker.swift
//  JMP
//
//  Created by Nishant Gupta on 16/04/19.
//  Copyright © 2019 GTrac. All rights reserved.
//

import Foundation
import UIKit
extension UIDatePicker {
    
    func setDateOfBirth() {
        let calendar = Calendar.current
        var minDateComponent = calendar.dateComponents([.day,.month,.year], from: Date())
        minDateComponent.day = minDateComponent.day!
        
        minDateComponent.month =  minDateComponent.month!
        minDateComponent.year =  minDateComponent.year! - 70
        
        let minDate = calendar.date(from: minDateComponent)
        
        var maxDateComponent = calendar.dateComponents([.day,.month,.year], from: Date())
        maxDateComponent.day = minDateComponent.day!
        maxDateComponent.month =  minDateComponent.month!
        maxDateComponent.year =  minDateComponent.year! + 58
        
        let maxDate = calendar.date(from: maxDateComponent)
        self.minimumDate = minDate
        self.maximumDate = maxDate
    }
    func setExpectedMoveDate() {
        let calendar = Calendar.current
        var minDateComponent = calendar.dateComponents([.day,.month,.year], from: Date())
        minDateComponent.day = minDateComponent.day! + 4
        
        minDateComponent.month =  minDateComponent.month!
        minDateComponent.year =  minDateComponent.year!
        
        let minDate = calendar.date(from: minDateComponent)
        
        var maxDateComponent = calendar.dateComponents([.day,.month,.year], from: Date())
        maxDateComponent.day = minDateComponent.day! + 31
        maxDateComponent.month =  minDateComponent.month!
        maxDateComponent.year =  minDateComponent.year!
        
        let maxDate = calendar.date(from: maxDateComponent)
        self.minimumDate = minDate
        self.maximumDate = maxDate
    }
    func setSurveyDate(Year: String, Month: String, Day: String) {
        let calendar = Calendar.current
        var minDateComponent = calendar.dateComponents([.day,.month,.year], from: Date())
        
        
        minDateComponent.day = minDateComponent.day! + 2
        
        minDateComponent.month =  minDateComponent.month!
        
        
        
        let minDate = calendar.date(from: minDateComponent)
        
        var maxDateComponent = calendar.dateComponents([.day,.month,.year], from: Date())
        
        maxDateComponent.day = Day.stringToInt()! - 2
        maxDateComponent.month =  Month.stringToInt()!
        maxDateComponent.year =  Year.stringToInt()!
        
        let maxDate = calendar.date(from: maxDateComponent)
        self.minimumDate = minDate
        self.maximumDate = maxDate
    }
    
}


