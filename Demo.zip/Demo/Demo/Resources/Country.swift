//
//  Country.swift
//  JMP
//
//  Created by Nishant Gupta on 30/04/19.
//  Copyright © 2019 GTrac. All rights reserved.
//

import Foundation
import Foundation

struct Country {
    let name: String
    let code: String
}

final class CountryHelper {
    class func allCountries() -> [Country] {
        var countries = [Country]()
        
        for code in Locale.isoRegionCodes as [String] {
            if let name = Locale.autoupdatingCurrent.localizedString(forRegionCode: code) {
                countries.append(Country(name: name, code: code))
            }
        }
        
        return countries
    }
}
