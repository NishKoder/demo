//
//  AppConstants.swift
//  JMP
//
//  Created by Nishant Gupta on 16/04/19.
//  Copyright © 2019 GTrac. All rights reserved.
//

import Foundation
class AppConstants {
    
    //API - Base Service Url
    static let kBASE_SERVICE_URL = "xxxx"

    
    //Method - Name
    static let  METHOD_LOGIN = "login"

    //userid,profile_picture

    static let ZEROINT = 0
    static let ONEINT = 1

    
    static let STATUSBAR = "statusBar"
    static let FORGROUND = "foregroundColor"

    //API-Response Txt
    static let TYPETXT = "type"
    static let CODETXT = "code"
    static let STATUSTXT = "status"
    static let MESSAGETXT = "message"
    static let DEVMESSAGETXT = "dev_message"
    
  
    
    
 
    
    
}
