//
//  UIImageView.swift
//  JMP
//
//  Created by Nishant Gupta on 16/04/19.
//  Copyright © 2019 GTrac. All rights reserved.
//

import Foundation
import UIKit

extension UIImageView {
    
    func makeRoundedq() {
        let radius = self.frame.width/2.0
        self.layer.cornerRadius = radius
        self.layer.masksToBounds = true
    }
   
  
    
}
