//
//  UITextView.swift
//  JMP
//
//  Created by Nishant Gupta on 22/04/19.
//  Copyright © 2019 GTrac. All rights reserved.
//

import Foundation
import UIKit

extension UITextView{
    
    func makeBoarder(){
        self.layer.borderColor = UIColor.lightGray.cgColor
        self.layer.borderWidth = 0.4
        self.layer.cornerRadius = 4
    }
    
    func paddingAll(top: CGFloat,left: CGFloat, bottom: CGFloat,right: CGFloat){
        self.textContainerInset =
            UIEdgeInsets(top: top,left: left,bottom: bottom,right: right);
    }
}
