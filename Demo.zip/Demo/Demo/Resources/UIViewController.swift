//
//  UIViewController.swift
//  JMP
//
//  Created by Nishant Gupta on 16/04/19.
//  Copyright © 2019 GTrac. All rights reserved.
//

import Foundation
import UIKit

extension UIViewController {
    
    func openEmail(email : String){
        if let url = URL(string: "mailto:\(email)") {
            if #available(iOS 10.0, *) {
                UIApplication.shared.open(url)
            } else {
                UIApplication.shared.openURL(url)
            }
        }
    }
    func dialNumber(number : String) {
       let number1 = number.replacingOccurrences(of: " ", with: "")
        if let url = URL(string: "tel://\(number1)"),
            UIApplication.shared.canOpenURL(url) {
            if #available(iOS 10, *) {
                UIApplication.shared.open(url, options: [:], completionHandler:nil)
            } else {
                UIApplication.shared.openURL(url)
            }
        } else {
            // add error message here
        }
    }
    func setStatusBarStyle(_ style: UIStatusBarStyle) {
        if let statusBar = UIApplication.shared.value(forKey: AppConstants.STATUSBAR) as? UIView {
            statusBar.backgroundColor = style == .lightContent ? UIColor.init(displayP3Red: 0.0/255.0, green: 187.0/255.0, blue: 204/255.0, alpha: 1.0) : .white
            statusBar.setValue(style == .lightContent ? UIColor.white : .black, forKey: AppConstants.FORGROUND)
        }
    }
    func showToast(message : String) {
        
        let alert = UIAlertController(title: "", message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Ok", style: .default, handler: { action in
            switch action.style{
            case .default: break
               // self.navigationController?.popViewController(animated: true)
            case .cancel:
               break
                
            case .destructive:
                break
                
                
            @unknown default: break
                
            }}))
        
        self.present(alert, animated: true, completion: nil)
    }
    func showWithBackToast(message : String) {
        
        let alert = UIAlertController(title: "", message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Ok", style: .default, handler: { action in
            switch action.style{
            case .default:
            self.navigationController?.popViewController(animated: true)
                break
            case .cancel:
                break
                
            case .destructive:
                break
                
                
            @unknown default: break
                
            }}))
        
        self.present(alert, animated: true, completion: nil)
    }
    func hideKeyboardWhenTappedAround() {
        let tap: UITapGestureRecognizer =     UITapGestureRecognizer(target: self, action:    #selector(UIViewController.dismissKeyboard))
        tap.cancelsTouchesInView = false
        view.addGestureRecognizer(tap)
    }
    @objc func dismissKeyboard() {
        view.endEditing(true)
    }
    
    
}
