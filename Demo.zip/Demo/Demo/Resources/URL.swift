//
//  URL.swift
//  JMP
//
//  Created by Nishant Gupta on 23/04/19.
//  Copyright © 2019 GTrac. All rights reserved.
//

import Foundation
import UIKit

extension URL{
    static var documentsDirectory: URL {
        let documentsDirectory = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true).first!
        return try! documentsDirectory.asURL()
    }
    
    static func urlInDocumentsDirectory(with filename: String) -> URL {
        return documentsDirectory.appendingPathComponent(filename)
    }
    
}
