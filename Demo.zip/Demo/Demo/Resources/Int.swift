//
//  Int.swift
//  JMP
//
//  Created by Nishant Gupta on 16/04/19.
//  Copyright © 2019 GTrac. All rights reserved.
//

import Foundation
extension Int {
    
    func intToString() -> String? {
        return String(self)
    }
}
