//
//  Optional.swift
//  JMP
//
//  Created by Nishant Gupta on 23/04/19.
//  Copyright © 2019 GTrac. All rights reserved.
//

import Foundation
import UIKit

extension Optional {
    
    func ifValue(_ valueHandler: (Wrapped) -> Void) {
        switch self {
        case .some(let wrapped): valueHandler(wrapped)
        default: break
        }
    }
    
}
